const JSON_HEADERS = { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' };

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    const cors = corsHeaders(origin, env.ALLOWED_ORIGIN || '*');
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

    const url = new URL(request.url);
    try {
      let response;
      if (url.pathname === '/health' && request.method === 'GET') {
        response = json(200, { success: true, message: 'HSM AI Worker aktif.', gemini: Boolean(env.GEMINI_API_KEY), cloudflare: Boolean(env.CF_ACCOUNT_ID && env.CF_API_TOKEN) });
      } else if (url.pathname === '/api' && request.method === 'POST') {
        response = await chat(request, env);
      } else if (url.pathname === '/image-generate' && request.method === 'POST') {
        response = await imageGenerate(request, env);
      } else if (url.pathname === '/image-edit' && request.method === 'POST') {
        response = await imageEdit(request, env);
      } else if (url.pathname === '/image-search' && request.method === 'POST') {
        response = await imageSearch(request, env);
      } else if (url.pathname === '/image-proxy' && request.method === 'POST') {
        response = await imageProxy(request);
      } else {
        response = json(404, { success: false, message: 'Endpoint tidak ditemukan.' });
      }
      return withHeaders(response, cors);
    } catch (error) {
      return withHeaders(json(500, { success: false, message: safeError(error) }), cors);
    }
  }
};

function corsHeaders(origin, allowed) {
  const ok = allowed === '*' || !origin || origin === allowed;
  return {
    'Access-Control-Allow-Origin': ok ? (allowed === '*' ? '*' : allowed) : 'null',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type,Accept',
    'Vary': 'Origin'
  };
}
function withHeaders(response, extra) { const h = new Headers(response.headers); for (const [k,v] of Object.entries(extra)) h.set(k,v); return new Response(response.body,{status:response.status,headers:h}); }
function json(status, data) { return new Response(JSON.stringify(data), { status, headers: JSON_HEADERS }); }
function safeError(e) { return e instanceof Error ? e.message : 'Terjadi kesalahan pada Worker.'; }
async function bodyJson(request) { try { return await request.json(); } catch { throw new Error('Body JSON tidak valid.'); } }
function clamp(n,min,max){ return Math.max(min,Math.min(max,n)); }
function cleanText(v){ return String(v ?? '').trim(); }

function parseDataUrl(value) {
  const s = cleanText(value);
  if (!s) return { mime:'', base64:'', bytes:0 };
  const m = s.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,([A-Za-z0-9+/=\r\n]+)$/);
  if (!m) throw new Error('Format gambar tidak valid.');
  const mime=m[1].toLowerCase();
  if (!['image/jpeg','image/png','image/webp','image/gif'].includes(mime)) throw new Error('Format gambar harus JPG, PNG, WEBP, atau GIF.');
  const base64=m[2].replace(/\s+/g,'');
  const bytes=Math.floor(base64.length*3/4);
  if (bytes > 4*1024*1024) throw new Error('Ukuran gambar maksimal 4 MB.');
  return {mime,base64,bytes};
}

async function geminiGenerate(env, payload, modelOverride='') {
  if (!env.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY belum diset pada Worker.');
  const model=modelOverride || env.GEMINI_MODEL || 'gemini-2.5-flash';
  const endpoint=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
  const r=await fetch(endpoint,{method:'POST',headers:{'x-goog-api-key':env.GEMINI_API_KEY,'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify(payload)});
  const data=await r.json().catch(()=>({}));
  if(!r.ok||data.error) throw new Error('Gemini API: '+(data?.error?.message||`HTTP ${r.status}`));
  const parts=data?.candidates?.[0]?.content?.parts;
  const answer=Array.isArray(parts)?parts.map(p=>typeof p?.text==='string'?p.text:'').filter(Boolean).join('\n').trim():'';
  return {answer,data,model};
}
async function cloudflareRun(env, model, payload, accept='application/json') {
  if (!env.CF_ACCOUNT_ID || !env.CF_API_TOKEN) throw new Error('CF_ACCOUNT_ID atau CF_API_TOKEN belum diset pada Worker.');
  const endpoint=`https://api.cloudflare.com/client/v4/accounts/${encodeURIComponent(env.CF_ACCOUNT_ID)}/ai/run/${model}`;
  const r=await fetch(endpoint,{method:'POST',headers:{Authorization:`Bearer ${env.CF_API_TOKEN}`,'Content-Type':'application/json',Accept:accept},body:JSON.stringify(payload)});
  return r;
}

async function chat(request, env) {
  const data=await bodyJson(request);
  const text=cleanText(data.text); const style=cleanText(data.style||'baku').toLowerCase(); const intensity=clamp(Number(data.intensity||8),1,10); const image=parseDataUrl(data.image_data_url||'');
  if(!text&&!image.base64) return json(422,{success:false,message:'Masukkan pertanyaan atau kirim gambar terlebih dahulu.'});
  if(text.length>8000) return json(422,{success:false,message:'Pesan terlalu panjang. Maksimal 8.000 karakter.'});
  const styles={baku:'Gunakan Bahasa Indonesia baku, jelas, alami, dan mudah dipahami.',formal:'Gunakan Bahasa Indonesia formal, profesional, dan terstruktur.',gaul:'Gunakan Bahasa Indonesia santai dan gaul, tetapi tetap sopan serta mudah dipahami.',betawi:'Gunakan nuansa percakapan Betawi yang ringan, alami, sopan, dan tidak berlebihan.',hybrid:'Gunakan campuran bahasa baku dan santai yang terasa natural serta modern.'};
  const detail=intensity<=3?'Jawab cukup ringkas, tetapi tetap utuh dan jelas.':intensity<=6?'Jawab dengan penjelasan sedang dan beberapa paragraf yang saling tersambung.':intensity<=8?'Jawab panjang, lengkap, mendalam, dan berikan konteks yang membantu.':'Jawab sangat panjang, lengkap, mendalam, dan menyeluruh. Jelaskan konteks, alasan, contoh, serta hal penting yang perlu diperhatikan.';
  const system=`Anda adalah HSM AI, asisten AI percakapan berbahasa Indonesia.\nJawab pertanyaan atau kerjakan perintah pengguna secara langsung. Jika pengguna mengirim gambar, analisis isi gambar tersebut dan gabungkan dengan pertanyaan pengguna bila ada.\nJangan memparafrasekan pertanyaan pengguna dan jangan membuat 15 variasi.\nBerikan SATU jawaban panjang yang menyatu. Utamakan ketepatan dan jangan mengarang fakta yang tidak diketahui.\n${styles[style]||styles.baku}\n${detail}`;
  const user=text||'Tolong analisis gambar ini secara lengkap.'; let warning='';
  if(env.GEMINI_API_KEY){
    try{
      const parts=[{text:user}]; if(image.base64) parts.push({inline_data:{mime_type:image.mime,data:image.base64}});
      const result=await geminiGenerate(env,{system_instruction:{parts:[{text:system}]},contents:[{role:'user',parts}],generationConfig:{temperature:clamp(.35+intensity*.04,.38,.78),topP:.9,maxOutputTokens:3500}});
      if(result.answer) return json(200,{success:true,answer:result.answer,model:result.model,provider:'Gemini',warning:''});
    }catch(e){warning=safeError(e)+' Sistem mencoba Cloudflare sebagai cadangan.';}
  }
  if(env.CF_ACCOUNT_ID&&env.CF_API_TOKEN){
    const model=image.base64?(env.CF_VISION_MODEL||'@cf/meta/llama-3.2-11b-vision-instruct'):(env.CF_TEXT_MODEL||'@cf/meta/llama-3.1-8b-instruct-fast');
    const content=image.base64?[{type:'text',text:user},{type:'image_url',image_url:{url:`data:${image.mime};base64,${image.base64}`}}]:user;
    const r=await cloudflareRun(env,model,{messages:[{role:'system',content:system},{role:'user',content}],temperature:clamp(.35+intensity*.04,.38,.78),top_p:.9,max_tokens:3500},'application/json');
    const d=await r.json().catch(()=>({}));
    if(!r.ok||(d.success===false)) return json(r.status||502,{success:false,message:(warning?warning+' ':'')+'Cloudflare AI: '+(d?.errors?.[0]?.message||d?.message||`HTTP ${r.status}`)});
    const p=d?.result?.response ?? d?.result?.choices?.[0]?.message?.content;
    const answer=typeof p==='string'?p:(p?.answer||p?.content||p?.text||p?.response||'');
    if(answer) return json(200,{success:true,answer:String(answer).trim(),model,provider:'Cloudflare',warning});
  }
  return json(502,{success:false,message:warning||'AI belum dikonfigurasi pada Worker.'});
}

function dimensions(ratio){return {'1:1':[1024,1024],'16:9':[1344,768],'9:16':[768,1344],'4:3':[1152,896],'3:4':[896,1152]}[ratio]||[1024,1024];}
function styleHint(style){return {anime:'Buat dengan gaya anime yang bersih, detail, dan menarik.',ilustrasi:'Buat sebagai ilustrasi digital yang rapi dan artistik.','3d':'Buat sebagai render 3D yang modern dan detail.',poster:'Buat seperti poster visual yang kuat, rapi, dan menarik.'}[style]||'Buat secara realistis, detail, dan enak dilihat.';}
async function cloudflareImage(env,prompt,ratio){
  const [width,height]=dimensions(ratio); const model=env.CF_IMAGE_MODEL||'@cf/black-forest-labs/flux-1-schnell';
  const r=await cloudflareRun(env,model,{prompt,width,height,num_steps:4,guidance:3.5},'image/png,application/json');
  if(!r.ok){const t=await r.text();let msg=t;try{const d=JSON.parse(t);msg=d?.errors?.[0]?.message||d?.message||t}catch{} throw new Error('Cloudflare Image AI: '+msg.slice(0,300));}
  const ct=(r.headers.get('content-type')||'').split(';')[0].toLowerCase();
  if(ct.startsWith('image/')){const ab=await r.arrayBuffer();return {dataUrl:`data:${ct};base64,${arrayBufferToBase64(ab)}`,model};}
  const d=await r.json().catch(()=>({})); const b64=d?.result?.image; if(!b64) throw new Error('Respons gambar tidak valid dari Cloudflare.');
  return {dataUrl:`data:image/png;base64,${b64}`,model};
}
async function imageGenerate(request,env){
  const d=await bodyJson(request); const prompt=cleanText(d.prompt), style=cleanText(d.style||'realistis'), ratio=cleanText(d.ratio||'1:1');
  if(!prompt)return json(422,{success:false,message:'Masukkan prompt gambar terlebih dahulu.'}); if(prompt.length>2000)return json(422,{success:false,message:'Prompt terlalu panjang. Maksimal 2.000 karakter.'});
  try{const x=await cloudflareImage(env,`${prompt}\n\n${styleHint(style)}`,ratio);return json(200,{success:true,image_data_url:x.dataUrl,model:x.model});}catch(e){return json(502,{success:false,message:safeError(e)});}
}
async function imageEdit(request,env){
  const d=await bodyJson(request); const prompt=cleanText(d.prompt),style=cleanText(d.style||'realistis'),ratio=cleanText(d.ratio||'1:1'); let source;
  try{source=parseDataUrl(d.source_image||'')}catch(e){return json(422,{success:false,message:safeError(e)})}
  if(!source.base64)return json(422,{success:false,message:'Gambar sumber tidak boleh kosong.'}); if(!prompt)return json(422,{success:false,message:'Masukkan instruksi edit terlebih dahulu.'});
  let summary='Subjek dan detail gambar asli perlu dipertahankan sebisa mungkin.'; let note='Hasil dibuat berdasarkan instruksi pengguna.';
  if(env.GEMINI_API_KEY){try{const g=await geminiGenerate(env,{contents:[{role:'user',parts:[{text:'Analisis gambar ini untuk kebutuhan edit ulang. Jawab singkat dalam Bahasa Indonesia dengan menyebut subjek utama, latar, warna dominan, posisi/pose, suasana, dan detail penting yang harus dipertahankan. Maksimal 180 kata.'},{inline_data:{mime_type:source.mime,data:source.base64}}]}],generationConfig:{temperature:.25,topP:.8,maxOutputTokens:350}});if(g.answer){summary=g.answer;note='Gambar sumber dianalisis Gemini sebelum dibuat ulang.'}}catch{note='Gemini tidak tersedia; gambar dibuat ulang terutama dari instruksi pengguna.'}}
  const finalPrompt=`Buat gambar baru berdasarkan referensi gambar yang telah dianalisis AI, bukan dari nol.\n\nRingkasan gambar asli: ${summary}\n\nInstruksi edit pengguna: ${prompt}\n\nPertahankan identitas, komposisi umum, dan elemen inti gambar asli selama tidak bertentangan dengan instruksi edit. Jika pengguna meminta penggantian latar, suasana, warna, atau gaya, ubah bagian tersebut dengan jelas.\n\n${styleHint(style)}\n\nHasil akhir harus terlihat rapi, meyakinkan, dan berkualitas tinggi.`;
  try{const x=await cloudflareImage(env,finalPrompt,ratio);return json(200,{success:true,image_data_url:x.dataUrl,model:x.model,note});}catch(e){return json(502,{success:false,message:safeError(e)});}
}

async function normalizeQuery(env,q){
  if(!env.GEMINI_API_KEY)return {english:q,keywords:tokens(q),used:false};
  try{const g=await geminiGenerate(env,{contents:[{role:'user',parts:[{text:`Ubah query pencarian gambar ini ke bahasa Inggris yang natural dan keluarkan JSON valid saja dengan bentuk {"english_query":"...","keywords":["..."]}. Query: ${q}`}]}],generationConfig:{temperature:.1,maxOutputTokens:160}}); const raw=g.answer.replace(/^```json\s*/i,'').replace(/```$/,'').trim(); const p=JSON.parse(raw);return {english:cleanText(p.english_query)||q,keywords:Array.isArray(p.keywords)?p.keywords.map(cleanText).filter(Boolean):tokens(q),used:true};}catch{return {english:q,keywords:tokens(q),used:false};}
}
function tokens(s){return String(s).toLowerCase().normalize('NFKD').replace(/[^a-z0-9\s-]/g,' ').split(/\s+/).filter(x=>x.length>2).slice(0,12);}
function score(item,keys){const hay=`${item.title||''} ${(item.tags||[]).join(' ')} ${item.description||''}`.toLowerCase();const hits=keys.filter(k=>hay.includes(String(k).toLowerCase())).length;const pct=keys.length?Math.round(hits/keys.length*100):50;return {pct,strict:pct>=60,level:pct>=90?'Sangat tepat':pct>=65?'Tepat':pct>=45?'Cocok':'Terkait'};}
async function imageSearch(request,env){
  const d=await bodyJson(request);const q=cleanText(d.q),category=cleanText(d.category||'all');if(!q)return json(422,{success:false,message:'Masukkan kata kunci pencarian gambar.'});if(q.length>200)return json(422,{success:false,message:'Kata kunci terlalu panjang. Maksimal 200 karakter.'});
  const n=await normalizeQuery(env,q); const keys=(n.keywords?.length?n.keywords:tokens(n.english)); const items=[];
  const params=new URLSearchParams({q:n.english,page_size:'40',mature:'false'});if(['photograph','illustration','digitized_artwork'].includes(category))params.set('category',category);
  try{const r=await fetch('https://api.openverse.org/v1/images/?'+params.toString(),{headers:{Accept:'application/json'}});const j=await r.json();for(const [i,x] of (j.results||[]).entries()){items.push({id:'ov-'+(x.id||i),title:x.title||'Tanpa judul',thumbnail:x.thumbnail||x.url,url:x.url,landing_url:x.foreign_landing_url||x.url,creator:x.creator||'',source:x.source||x.provider||'Openverse',license:(x.license||'').toUpperCase(),width:Number(x.width||0),height:Number(x.height||0),tags:(x.tags||[]).map(t=>t?.name||'').filter(Boolean),description:x.description||''});}}catch{}
  try{const wp=new URLSearchParams({action:'query',format:'json',formatversion:'2',generator:'search',gsrnamespace:'6',gsrlimit:'24',gsrsearch:n.english,prop:'imageinfo',iiprop:'url|size|mime',iiurlwidth:'720',origin:'*'});const r=await fetch('https://commons.wikimedia.org/w/api.php?'+wp.toString(),{headers:{Accept:'application/json'}});const j=await r.json();for(const x of (j?.query?.pages||[])){const info=x?.imageinfo?.[0]||{};if(!info.url)continue;items.push({id:'wc-'+x.pageid,title:String(x.title||'').replace(/^File:/i,''),thumbnail:info.thumburl||info.url,url:info.url,landing_url:'https://commons.wikimedia.org/wiki/'+encodeURIComponent(String(x.title||'').replace(/ /g,'_')),creator:'',source:'Wikimedia Commons',license:'',width:Number(info.width||0),height:Number(info.height||0),tags:[],description:''});}}catch{}
  const seen=new Set(), ranked=[];for(const x of items){const key=(x.url||x.thumbnail||x.id);if(!key||seen.has(key))continue;seen.add(key);const s=score(x,keys);ranked.push({...x,match_level:s.level,match_percent:s.pct,_strict:s.strict});}ranked.sort((a,b)=>(Number(b._strict)-Number(a._strict))||(b.match_percent-a.match_percent));const results=ranked.slice(0,24).map(({_strict,...x})=>x);const strict=ranked.filter(x=>x._strict).length;
  return json(200,{success:true,query:q,normalized_query:n.english,keywords:keys,used_ai_normalization:n.used,strict_count:strict,count:results.length,results,cached:false});
}

function blockedHost(host){const h=host.toLowerCase();if(h==='localhost'||h.endsWith('.local')||h==='127.0.0.1'||h==='0.0.0.0'||h==='::1')return true;if(/^10\./.test(h)||/^192\.168\./.test(h)||/^169\.254\./.test(h)||/^172\.(1[6-9]|2\d|3[01])\./.test(h))return true;return false;}
async function imageProxy(request){
  const d=await bodyJson(request);const raw=cleanText(d.url);let u;try{u=new URL(raw)}catch{return json(422,{success:false,message:'URL gambar tidak valid.'})}if(u.protocol!=='https:'||blockedHost(u.hostname))return json(422,{success:false,message:'Hanya URL HTTPS publik yang diizinkan.'});
  const r=await fetch(u.toString(),{redirect:'follow',headers:{Accept:'image/avif,image/webp,image/png,image/jpeg,image/gif,*/*;q=0.5'}});if(!r.ok)return json(502,{success:false,message:'Gambar tidak dapat diambil dari sumber.'});const ct=(r.headers.get('content-type')||'').split(';')[0].toLowerCase();if(!['image/jpeg','image/png','image/webp','image/gif','image/avif'].includes(ct))return json(422,{success:false,message:'Format gambar tidak didukung.'});const ab=await r.arrayBuffer();if(ab.byteLength>4*1024*1024)return json(413,{success:false,message:'Ukuran gambar lebih dari 4 MB.'});return json(200,{success:true,mime:ct,size:ab.byteLength,data_url:`data:${ct};base64,${arrayBufferToBase64(ab)}`});
}
function arrayBufferToBase64(buffer){const bytes=new Uint8Array(buffer);let binary='';const chunk=0x8000;for(let i=0;i<bytes.length;i+=chunk)binary+=String.fromCharCode(...bytes.subarray(i,Math.min(i+chunk,bytes.length)));return btoa(binary);}
